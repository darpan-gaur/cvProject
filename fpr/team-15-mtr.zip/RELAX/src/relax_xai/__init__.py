"""
RELAX

A framework for explainability in representation learning.
"""

__version__ = "0.1.0"
__author__ = 'Kristoffer Wickstrøm'
__credits__ = 'UiT The Arctic University of Norway'